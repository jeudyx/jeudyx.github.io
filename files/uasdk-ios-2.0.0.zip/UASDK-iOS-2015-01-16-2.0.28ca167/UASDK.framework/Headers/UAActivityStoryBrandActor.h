//
//  UAActivityStoryBrandActor.h
//  UA
//
//  Created by Jeff Oliver on 6/19/14.
//  Copyright (c) 2014 MapMyFitness Inc. All rights reserved.
//

#import "UAActivityStoryActor.h"

@interface UAActivityStoryBrandActor : UAActivityStoryActor

@end
